const arr1 = [0, 1, 2, 3, 4];
const arr2 = [5, 6, 7, 8, 9];

const mergedArr = [...arr1, ...arr2];

console.log(mergedArr);
